"""
尝试使用加法运算，新型残差模块！包装RSC
"""
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import models
import torch.nn.functional as F
from thop import profile
from functools import partial

nonlinearity = partial(F.relu, inplace=True)


class MLConv(nn.Module):
    def __init__(self, in_channels, dilation):
        super(MLConv, self).__init__()
        self.deconv1 = nn.Conv2d(
            in_channels, in_channels // 4, (1, dilation * 2 + 1), padding=(0, dilation)
        )
        self.deconv2 = nn.Conv2d(
            in_channels, in_channels // 4, (dilation * 2 + 1, 1), padding=(dilation, 0)
        )
        self.deconv3 = nn.Conv2d(
            in_channels, in_channels // 4, (dilation * 2 + 1, 1), padding=(dilation, 0)
        )
        self.deconv4 = nn.Conv2d(
            in_channels, in_channels // 4, (1, dilation * 2 + 1), padding=(0, dilation)
        )
        self.bn = nn.BatchNorm2d(in_channels)
        self.relu = nn.ReLU()

    def forward(self, x):
        x1 = self.deconv1(x)
        x2 = self.deconv2(x)
        """
            1.先对原始的输入张量进行水平变换和垂直变换，得到对角线卷积的输入张量。
            2.对得到的对角线卷积输入张量进行卷积操作。
            3.对卷积操作后的张量进行水平反变换和垂直反变换，得到最终的输出张量。
        """
        x3 = self.inv_h_transform(self.deconv3(self.h_transform(x)))
        x4 = self.inv_v_transform(self.deconv4(self.v_transform(x)))
        x = torch.cat((x1, x2, x3, x4), 1)  # 经过米字卷积后的结果是拼接在一起的
        x = self.bn(x)
        x = self.relu(x)
        return x

    def h_transform(self, x):
        shape = x.size()
        x = torch.nn.functional.pad(x, (0, shape[-1]))
        x = x.reshape(shape[0], shape[1], -1)[..., :-shape[-1]]
        x = x.reshape(shape[0], shape[1], shape[2], 2 * shape[3] - 1)
        return x

    def inv_h_transform(self, x):
        shape = x.size()
        x = x.reshape(shape[0], shape[1], -1).contiguous()
        x = torch.nn.functional.pad(x, (0, shape[-2]))
        x = x.reshape(shape[0], shape[1], shape[-2], 2 * shape[-2])
        x = x[..., 0: shape[-2]]
        return x

    def v_transform(self, x):
        x = x.permute(0, 1, 3, 2)
        shape = x.size()
        x = torch.nn.functional.pad(x, (0, shape[-1]))
        x = x.reshape(shape[0], shape[1], -1)[..., :-shape[-1]]
        x = x.reshape(shape[0], shape[1], shape[2], 2 * shape[3] - 1)
        return x.permute(0, 1, 3, 2)

    def inv_v_transform(self, x):
        x = x.permute(0, 1, 3, 2)
        shape = x.size()
        x = x.reshape(shape[0], shape[1], -1)
        x = torch.nn.functional.pad(x, (0, shape[-2]))
        x = x.reshape(shape[0], shape[1], shape[-2], 2 * shape[-2])
        x = x[..., 0: shape[-2]]
        return x.permute(0, 1, 3, 2)


class ML(nn.Module):
    def __init__(self, in_channels, out_channels1, atrous_rates):
        super(ML, self).__init__()
        out_channels = out_channels1
        self.cb1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU())
        self.cb2 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels1, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU())

        rate1, rate2, rate3 = tuple(atrous_rates)
        self.conv1 = MLConv(in_channels, rate1)
        self.conv2 = MLConv(in_channels, rate2)
        self.conv3 = MLConv(in_channels, rate3)
        # CBAM attention
        self.attention = cbam_block(out_channels * 5)

        self.project = nn.Sequential(
            nn.Conv2d(5 * out_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Dropout(0.5)
        )

    def forward(self, x):
        cb1 = self.cb1(x)
        cb2 = self.cb2(x)
        c1 = self.conv1(x)
        c2 = self.conv2(x)
        c3 = self.conv3(x)
        res = torch.cat([cb1, cb2, c1, c2, c3], dim=1)

        # apply CBAM attention
        res = self.attention(res)
        return self.project(res)


class Conv(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1):  # ch_in, ch_out, kernel, stride, padding, groups
        super(Conv, self).__init__()
        self.conv = nn.Conv2d(c1, c2, k, s)
        self.bn = nn.BatchNorm2d(c2)
        self.relu = nn.ReLU()

    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))

class RSC(nn.Module):
    # ResNet bottleneck
    def __init__(self, c1, c2,dilation, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super(RSC, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = MLConv(c_,dilation)
        self.cv3 = Conv(c_, c2, 1, 1)

    def forward(self, x):
        return self.cv3(self.cv2(self.cv1(x)))

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=8):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        # 利用1x1卷积代替全连接
        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class cbam_block(nn.Module):
    def __init__(self, channel, ratio=8, kernel_size=7):
        super(cbam_block, self).__init__()
        self.channelattention = ChannelAttention(channel, ratio=ratio)
        self.spatialattention = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        x = x * self.channelattention(x)
        x = x * self.spatialattention(x)
        return x


class DecoderBlock(nn.Module):
    def __init__(self, in_channels, n_filters):
        super(DecoderBlock, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels // 4, 1)
        self.norm1 = nn.BatchNorm2d(in_channels // 4)
        self.relu1 = nonlinearity

        self.deconv2 = nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 3, stride=2, padding=1, output_padding=1)
        self.norm2 = nn.BatchNorm2d(in_channels // 4)
        self.relu2 = nonlinearity

        self.conv3 = nn.Conv2d(in_channels // 4, n_filters, 1)
        self.norm3 = nn.BatchNorm2d(n_filters)
        self.relu3 = nonlinearity

    def forward(self, x):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)
        x = self.deconv2(x)
        x = self.norm2(x)
        x = self.relu2(x)
        x = self.conv3(x)
        x = self.norm3(x)
        x = self.relu3(x)
        return x


class DinkNet34(nn.Module):
    def __init__(self, num_classes=1, num_channels=3):
        super(DinkNet34, self).__init__()

        filters = [64, 128, 256, 512]
        resnet = models.resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.encoder3 = resnet.layer3
        self.encoder4 = resnet.layer4


        self.ml1 = RSC(64,64, 4)
        self.ml2 = RSC(128,128, 3)
        self.ml3 = RSC(256,256, 2)
        self.ml = ML(512, 512, [2, 3, 4])

        self.decoder4 = DecoderBlock(filters[3], filters[2])
        self.decoder3 = DecoderBlock(filters[2], filters[1])
        self.decoder2 = DecoderBlock(filters[1], filters[0])
        self.decoder1 = DecoderBlock(filters[0], filters[0])

        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x = self.firstmaxpool(x)
        e1 = self.encoder1(x)
        n1 = self.ml1(e1)
        e2 = self.encoder2(e1)
        n2 = self.ml2(e2)
        e3 = self.encoder3(e2)
        n3 = self.ml3(e3)
        e4 = self.encoder4(e3)

        # Center
        # e4 = self.dblock(e4)
        e4 = self.ml(e4)

        # Decoder
        d4 = self.decoder4(e4) + e3 + n3
        d3 = self.decoder3(d4) + e2 + n2
        d2 = self.decoder2(d3) + e1 + n1
        d1 = self.decoder1(d2)

        out = self.finaldeconv1(d1)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)

        return torch.sigmoid(out)


if __name__ == "__main__":
    print('==> Building model..')
    model = DinkNet34()

    dummy_input = torch.randn(1, 3, 1024, 1024)
    flops, params = profile(model, (dummy_input,))
    print('flops: ', flops, 'params: ', params)
    print('flops: %.2f G, params: %.2f M' % (flops / 1000000.0 / 1024.0, params / 1000000.0))