import numpy
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
import matplotlib.pyplot as plt
import numpy as np
from networks.DSConv_pro import DSConv
from functools import partial

nonlinearity = partial(F.relu, inplace=True)

class GroupBatchnorm2d(nn.Module):
    def __init__(self, c_num: int,
                 group_num: int = 16,
                 eps: float = 1e-10
                 ):
        super(GroupBatchnorm2d, self).__init__()
        assert c_num >= group_num
        self.group_num = group_num
        self.weight = nn.Parameter(torch.randn(c_num, 1, 1))
        self.bias = nn.Parameter(torch.zeros(c_num, 1, 1))
        self.eps = eps

    def forward(self, x):
        N, C, H, W = x.size()
        x = x.view(N, self.group_num, -1)
        mean = x.mean(dim=2, keepdim=True)
        std = x.std(dim=2, keepdim=True)
        x = (x - mean) / (std + self.eps)
        x = x.view(N, C, H, W)
        return x * self.weight + self.bias


class SRU(nn.Module):
    def __init__(self,
                 oup_channels: int,
                 group_num: int = 16,
                 gate_treshold: float = 0.5,
                 torch_gn: bool = False
                 ):
        super().__init__()

        self.gn = nn.GroupNorm(num_channels=oup_channels, num_groups=group_num) if torch_gn else GroupBatchnorm2d(
            c_num=oup_channels, group_num=group_num)
        self.gate_treshold = gate_treshold
        self.sigomid = nn.Sigmoid()

    def forward(self, x):
        gn_x = self.gn(x)
        w_gamma = self.gn.weight / torch.sum(self.gn.weight)
        w_gamma = w_gamma.view(1, -1, 1, 1)
        reweigts = self.sigomid(gn_x * w_gamma)
        # Gate
        info_mask = reweigts >= self.gate_treshold
        noninfo_mask = reweigts < self.gate_treshold
        x_1 = info_mask * gn_x
        x_2 = noninfo_mask * gn_x
        x = self.reconstruct(x_1, x_2)
        return x

    def reconstruct(self, x_1, x_2):
        x_11, x_12 = torch.split(x_1, x_1.size(1) // 2, dim=1)
        x_21, x_22 = torch.split(x_2, x_2.size(1) // 2, dim=1)
        return torch.cat([x_11 + x_22, x_12 + x_21], dim=1)


class CRU(nn.Module):
    '''
    alpha: 0<alpha<1
    '''

    def __init__(self,
                 op_channel: int,
                 alpha: float = 1 / 2,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3,
                 ):
        super().__init__()
        self.up_channel = up_channel = int(alpha * op_channel)
        self.low_channel = low_channel = op_channel - up_channel
        self.squeeze1 = nn.Conv2d(up_channel, up_channel // squeeze_radio, kernel_size=1, bias=False)
        self.squeeze2 = nn.Conv2d(low_channel, low_channel // squeeze_radio, kernel_size=1, bias=False)
        # up
        self.GWC = nn.Conv2d(up_channel // squeeze_radio, op_channel, kernel_size=group_kernel_size, stride=1,
                             padding=group_kernel_size // 2, groups=group_size)
        self.PWC1 = nn.Conv2d(up_channel // squeeze_radio, op_channel, kernel_size=1, bias=False)
        # low
        self.PWC2 = nn.Conv2d(low_channel // squeeze_radio, op_channel - low_channel // squeeze_radio, kernel_size=1,
                              bias=False)
        self.advavg = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        # Split
        up, low = torch.split(x, [self.up_channel, self.low_channel], dim=1)
        up, low = self.squeeze1(up), self.squeeze2(low)
        # Transform
        Y1 = self.GWC(up) + self.PWC1(up)
        Y2 = torch.cat([self.PWC2(low), low], dim=1)
        # Fuse
        out = torch.cat([Y1, Y2], dim=1)
        out = F.softmax(self.advavg(out), dim=1) * out
        out1, out2 = torch.split(out, out.size(1) // 2, dim=1)
        return out1 + out2


class ScConv(nn.Module):
    def __init__(self,
                 op_channel: int,
                 group_num: int = 4,
                 gate_treshold: float = 0.5,
                 alpha: float = 1 / 2,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3,
                 ):
        super().__init__()
        self.SRU = SRU(op_channel,
                       group_num=group_num,
                       gate_treshold=gate_treshold)
        self.CRU = CRU(op_channel,
                       alpha=alpha,
                       squeeze_radio=squeeze_radio,
                       group_size=group_size,
                       group_kernel_size=group_kernel_size)

    def forward(self, x):
        x = self.SRU(x)
        x = self.CRU(x)
        return x


class ScConvWithChannelChange(nn.Module):
    def __init__(self,
                 input_channels: int,
                 output_channels: int,
                 group_num: int = 4,
                 gate_treshold: float = 0.5,
                 alpha: float = 1 / 2,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3,
                 ):
        super().__init__()
        self.input_conv = nn.Conv2d(input_channels, output_channels, kernel_size=1)
        self.sc_conv = ScConv(op_channel=output_channels,
                              group_num=group_num,
                              gate_treshold=gate_treshold,
                              alpha=alpha,
                              squeeze_radio=squeeze_radio,
                              group_size=group_size,
                              group_kernel_size=group_kernel_size)
        self.output_conv = nn.Conv2d(output_channels, output_channels, kernel_size=1)

    def forward(self, x):
        x = self.input_conv(x)
        x = self.sc_conv(x)
        x = self.output_conv(x)
        return x


class REBNCONV(nn.Module):
    def __init__(self,in_ch=3,out_ch=3,dirate=1):
        super(REBNCONV,self).__init__()
        self.conv_s1 = nn.Conv2d(in_ch,out_ch,3,padding=1*dirate,dilation=1*dirate)
        self.bn_s1 = nn.BatchNorm2d(out_ch)
        self.relu_s1 = nn.ReLU(inplace=True)
    def forward(self,x):
        hx = x
        xout = self.relu_s1(self.bn_s1(self.conv_s1(hx)))
        return xout

## upsample tensor 'src' to have the same spatial size with tensor 'tar'
def _upsample_like(src,tar):
    src = F.upsample(src,size=tar.shape[2:],mode='bilinear')
    return src


### RSU-7 ###
class RSU7(nn.Module):#UNet07DRES(nn.Module):
    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU7,self).__init__()
        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)
        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.MaxPool2d(2,stride=2,ceil_mode=True)
        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.MaxPool2d(2,stride=2,ceil_mode=True)
        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool3 = nn.MaxPool2d(2,stride=2,ceil_mode=True)
        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool4 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv5 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool5 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv6 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv7 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv6d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv5d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv4d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x):

        hx = x
        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)
        hx = self.pool3(hx3)

        hx4 = self.rebnconv4(hx)
        hx = self.pool4(hx4)

        hx5 = self.rebnconv5(hx)
        hx = self.pool5(hx5)

        hx6 = self.rebnconv6(hx)

        hx7 = self.rebnconv7(hx6)

        hx6d =  self.rebnconv6d(torch.cat((hx7,hx6),1))
        hx6dup = _upsample_like(hx6d,hx5)

        hx5d =  self.rebnconv5d(torch.cat((hx6dup,hx5),1))
        hx5dup = _upsample_like(hx5d,hx4)

        hx4d = self.rebnconv4d(torch.cat((hx5dup,hx4),1))
        hx4dup = _upsample_like(hx4d,hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4dup,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d + hxin


### RSU-6 ###
class RSU6(nn.Module):#UNet06DRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU6,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool3 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool4 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv5 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv6 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv5d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv4d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)
        hx = self.pool3(hx3)

        hx4 = self.rebnconv4(hx)
        hx = self.pool4(hx4)

        hx5 = self.rebnconv5(hx)

        hx6 = self.rebnconv6(hx5)


        hx5d =  self.rebnconv5d(torch.cat((hx6,hx5),1))
        hx5dup = _upsample_like(hx5d,hx4)

        hx4d = self.rebnconv4d(torch.cat((hx5dup,hx4),1))
        hx4dup = _upsample_like(hx4d,hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4dup,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d + hxin


### RSU-5 ###
class RSU5(nn.Module):#UNet05DRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU5,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool3 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv5 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv4d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)
        hx = self.pool3(hx3)

        hx4 = self.rebnconv4(hx)

        hx5 = self.rebnconv5(hx4)

        hx4d = self.rebnconv4d(torch.cat((hx5,hx4),1))
        hx4dup = _upsample_like(hx4d,hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4dup,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d + hxin

### RSU-4 ###
class RSU4(nn.Module):#UNet04DRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU4,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)

        hx4 = self.rebnconv4(hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d + hxin

### RSU-4F ###
class RSU4F(nn.Module):#UNet04FRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(RSU4F,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=2)
        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=4)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=8)

        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=4)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=2)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx2 = self.rebnconv2(hx1)
        hx3 = self.rebnconv3(hx2)

        hx4 = self.rebnconv4(hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4,hx3),1))
        hx2d = self.rebnconv2d(torch.cat((hx3d,hx2),1))
        hx1d = self.rebnconv1d(torch.cat((hx2d,hx1),1))

        return hx1d + hxin
#相同尺寸，面阵
class UpConv(nn.Module):
    def __init__(self, inc, outc, scale=2):
        super(UpConv, self).__init__()
        self.scale = scale
        self.conv = nn.Conv2d(inc, outc, 3, stride=1, padding=1)

    def forward(self, x):
        return self.conv(F.interpolate(x, scale_factor=self.scale, mode='bilinear', align_corners=True))
class CEBlock(nn.Module):
    def __init__(self, in_channels=16, out_channels=16):
        super(CEBlock, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.gap = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.BatchNorm2d(self.in_channels)
        )

        self.conv_gap = nn.Sequential(
            nn.Conv2d(self.in_channels, self.out_channels, 1, stride=1, padding=0),
            nn.BatchNorm2d(self.out_channels),
            nn.ReLU()
        )

        # Note: in paper here is naive conv2d, no bn-relu
        self.conv_last = nn.Conv2d(
            in_channels=self.out_channels,
            out_channels=self.out_channels,
            kernel_size=3,
            stride=1,
            padding=1)

    def forward(self, x):
        identity = x
        x = self.gap(x)
        x = self.conv_gap(x)
        x = identity + x
        x = self.conv_last(x)
        return x

def my_layer_norm(feat):
    mean = feat.mean((2, 3), keepdim=True)
    std = feat.std((2, 3), keepdim=True) + 1e-9
    feat = 2 * (feat - mean) / std - 1
    feat = 5 * feat
    return feat

class My_RSU7(nn.Module):#UNet07DRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(My_RSU7,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool3 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool4 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv5 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool5 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv6 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv7 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv6d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv5d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv4d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x,y):

        hx = x
        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)
        hx = self.pool3(hx3)

        hx4 = self.rebnconv4(hx)
        hx = self.pool4(hx4)

        hx5 = self.rebnconv5(hx)
        hx = self.pool5(hx5)

        hx6 = self.rebnconv6(hx)

        hx7 = self.rebnconv7(hx6)

        hx6d =  self.rebnconv6d(torch.cat((hx7,hx6),1))
        hx6dup = _upsample_like(hx6d,hx5)

        hx5d =  self.rebnconv5d(torch.cat((hx6dup,hx5),1))
        hx5dup = _upsample_like(hx5d,hx4)

        hx4d = self.rebnconv4d(torch.cat((hx5dup,hx4),1))
        hx4dup = _upsample_like(hx4d,hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4dup,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d*y + hxin*(1-y)
### RSU-6 ###
class My_RSU6(nn.Module):#UNet06DRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(My_RSU6,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool3 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool4 = nn.MaxPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv5 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv6 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv5d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv4d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x,y):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)
        hx = self.pool3(hx3)

        hx4 = self.rebnconv4(hx)
        hx = self.pool4(hx4)

        hx5 = self.rebnconv5(hx)

        hx6 = self.rebnconv6(hx5)


        hx5d =  self.rebnconv5d(torch.cat((hx6,hx5),1))
        hx5dup = _upsample_like(hx5d,hx4)

        hx4d = self.rebnconv4d(torch.cat((hx5dup,hx4),1))
        hx4dup = _upsample_like(hx4d,hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4dup,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d*y + hxin*(1-y)
### My_RSU-5 ###
class My_RSU_5(nn.Module):#UNet05DRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(My_RSU_5,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool3 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv5 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv4d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x, y):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)
        hx = self.pool3(hx3)

        hx4 = self.rebnconv4(hx)

        hx5 = self.rebnconv5(hx4)

        hx4d = self.rebnconv4d(torch.cat((hx5,hx4),1))
        hx4dup = _upsample_like(hx4d,hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4dup,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d*y + hxin*(1-y)
### My_RSU-4 ###
class My_RSU_4(nn.Module):#UNet04DRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(My_RSU_4,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.pool1 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=1)
        self.pool2 = nn.AvgPool2d(2,stride=2,ceil_mode=True)

        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=1)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=2)

        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=1)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x,y):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx = self.pool1(hx1)

        hx2 = self.rebnconv2(hx)
        hx = self.pool2(hx2)

        hx3 = self.rebnconv3(hx)

        hx4 = self.rebnconv4(hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4,hx3),1))
        hx3dup = _upsample_like(hx3d,hx2)

        hx2d = self.rebnconv2d(torch.cat((hx3dup,hx2),1))
        hx2dup = _upsample_like(hx2d,hx1)

        hx1d = self.rebnconv1d(torch.cat((hx2dup,hx1),1))

        return hx1d*y + hxin*(1-y)
### My_RSU-4F ###
class My_RSU4F(nn.Module):#UNet04FRES(nn.Module):

    def __init__(self, in_ch=3, mid_ch=12, out_ch=3):
        super(My_RSU4F,self).__init__()

        self.rebnconvin = REBNCONV(in_ch,out_ch,dirate=1)

        self.rebnconv1 = REBNCONV(out_ch,mid_ch,dirate=1)
        self.rebnconv2 = REBNCONV(mid_ch,mid_ch,dirate=2)
        self.rebnconv3 = REBNCONV(mid_ch,mid_ch,dirate=4)

        self.rebnconv4 = REBNCONV(mid_ch,mid_ch,dirate=8)

        self.rebnconv3d = REBNCONV(mid_ch*2,mid_ch,dirate=4)
        self.rebnconv2d = REBNCONV(mid_ch*2,mid_ch,dirate=2)
        self.rebnconv1d = REBNCONV(mid_ch*2,out_ch,dirate=1)

    def forward(self,x,y):

        hx = x

        hxin = self.rebnconvin(hx)

        hx1 = self.rebnconv1(hxin)
        hx2 = self.rebnconv2(hx1)
        hx3 = self.rebnconv3(hx2)

        hx4 = self.rebnconv4(hx3)

        hx3d = self.rebnconv3d(torch.cat((hx4,hx3),1))
        hx2d = self.rebnconv2d(torch.cat((hx3d,hx2),1))
        hx1d = self.rebnconv1d(torch.cat((hx2d,hx1),1))

        return hx1d*y + hxin*(1-y)

class ResDWC(nn.Module):
    def __init__(self, dim, kernel_size=3):
        super().__init__()

        self.dim = dim
        self.kernel_size = kernel_size

        self.conv = nn.Conv2d(dim, dim, kernel_size, 1, kernel_size // 2, groups=dim)

        # self.conv_constant = nn.Parameter(torch.eye(kernel_size).reshape(dim, 1, kernel_size, kernel_size))
        # self.conv_constant.requires_grad = False

    def forward(self, x):
        # return F.conv2d(x, self.conv.weight+self.conv_constant, self.conv.bias, stride=1, padding=self.kernel_size//2, groups=self.dim) # equal to x + conv(x)
        return x + self.conv(x)

#相同尺寸，线性
class GASF(nn.Module):
    def __init__(self,kernel_size):
        super(GASF, self).__init__()
        self.resdwc1 = DSCConv(512,kernel_size[2])
        self.resdwc2 = DSCConv(512,kernel_size[1])
        self.resdwc3 = DSCConv(512,kernel_size[0])
        self.Conv_Value = nn.Conv2d(512, 512, 1)
        self.Conv_Key = nn.Sequential(nn.Conv2d(512, 512, kernel_size=1, stride=1, padding=0),
                                      nn.BatchNorm2d(512),
                                      nn.ReLU()
                                      )
        self.Conv_Query = nn.Sequential(nn.Conv2d(512, 512, 1),
                                        nn.BatchNorm2d(512),
                                        nn.ReLU()
                                        )
        self.fc = nn.Sequential(nn.Linear(144, 72), nn.Dropout(0.2), nn.Linear(72, 144))
        self.ConvOut = nn.Conv2d(512,512,1)
        self.flatten = nn.Flatten(start_dim=2)
        # 给ConvOut初始化为0
        nn.init.constant_(self.ConvOut.weight, 0)
        nn.init.constant_(self.ConvOut.bias, 0)

    def forward(self, gx6, binary_16, binary_8, binary_4): # color, grey

        Query = self.Conv_Query(gx6)
        Query = Query.flatten(2).permute(0,2,1)
        key_16 = self.resdwc1(binary_16)
        key_8 = self.resdwc2(binary_8)
        key_4 = self.resdwc3(binary_4)

        Key = torch.cat([i for i in map(self.flatten, [key_16,key_8,key_4])],dim=-1)
        Value =  Key.contiguous().permute(0,2,1)
        Concat_QK = torch.matmul(Query, Key)
        Concat_QK = (512 ** -.5) * Concat_QK
        Concat_QK = F.softmax(Concat_QK, dim=-1)

        Aggregate_QKV = torch.matmul(Concat_QK, Value)
        # Aggregate_QKV = [batch, value_channels, h*w]
        Aggregate_QKV = Aggregate_QKV.permute(0, 2, 1).contiguous()
        # Aggregate_QKV = [batch, value_channels, h*w] -> [batch, value_channels, h, w]
        Aggregate_QKV = Aggregate_QKV.view(*gx6.shape)
        # Conv out
        Aggregate_QKV = self.ConvOut(Aggregate_QKV)

        return Aggregate_QKV+gx6
class channel_atten(nn.Module):
    def __init__(self, in_channels):
        super(channel_atten, self).__init__()
        self.module = nn.Sequential( nn.AdaptiveAvgPool2d(1), nn.Conv2d(in_channels, in_channels, 1), nn.BatchNorm2d(in_channels), nn.Sigmoid())
    def forward(self,x):
        res = x
        atten = self.module(x)
        out = torch.mul(atten,x) + res
        return out

### U^2-Net small ###
class MSN(nn.Module):

    def __init__(self,in_ch=3,out_ch=1):
        super(MSN,self).__init__()

        self.stage1 = RSU7(in_ch,32,64)
        self.pool12 = nn.MaxPool2d(2,stride=2,ceil_mode=True)
        self.stage2 = RSU6(64,32,128)
        self.pool23 = nn.MaxPool2d(2,stride=2,ceil_mode=True)
        self.stage3 = RSU5(128,64,256)
        self.pool34 = nn.AvgPool2d(2,stride=2,ceil_mode=True)
        self.stage4 = RSU4(256,128,512)
        self.pool45 = nn.AvgPool2d(2,stride=2,ceil_mode=True)
        self.stage5 = RSU4F(512,256,512)
        self.pool56 = nn.AvgPool2d(2,stride=2,ceil_mode=True)
        self.stage6 = RSU4F(512,256,512)

        self.stage11 = RSU7(in_ch,32,64)
        self.stage22 = RSU6(64,32,128)
        self.stage33 = RSU5(128,64,256)
        self.stage44 = RSU4(256,128,512)
        self.stage55 = RSU4F(512,256,512)
        self.stage66 = RSU4F(512,256,512)

        # self.stage1_my = My_RSU7(in_ch,32,64)
        # self.stage2_my = My_RSU6(64,32,128)
        self.stage3_my = My_RSU_5(128,64,256)
        self.stage4_my = My_RSU_4(256,128,512)
        self.stage5_my = My_RSU4F(512,256,512)
        # self.stage6_my = My_RSU4F(512,256,512)

        # decoder
        self.stage5d = RSU4F(1024,256,512)
        self.stage4d = RSU4(1024,128,256)
        self.stage3d = RSU5(512,64,128)
        self.stage2d = RSU6(256,32,64)
        self.stage1d = RSU7(128,16,64)
        self.stage55d = RSU4F(1024,256,512)
        self.stage44d = RSU4(1024,128,256)
        self.stage33d = RSU5(512,64,128)
        self.stage22d = RSU6(256,32,64)
        self.stage11d = RSU7(128,16,64)

        self.side1s = ScConvWithChannelChange(64,32)
        self.side1 = nn.Conv2d(32,out_ch,3,padding=1)
        self.side2s = ScConvWithChannelChange(128, 64)
        self.side2 = nn.Conv2d(64,out_ch,3,padding=1)
        self.side3s = ScConvWithChannelChange(256, 128)
        self.side3 = nn.Conv2d(128,out_ch,3,padding=1)
        self.side4 = nn.Conv2d(512,out_ch,3,padding=1)
        self.side5 = nn.Conv2d(512,out_ch,3,padding=1)
        self.side6 = nn.Conv2d(512,out_ch,3,padding=1)

        self.decoder4 = DDSCDecoderBlock(512, 512)
        self.decoder3 = TwoDSCDecoderBlock(512, 512)
        self.decoder2 = TwoDSCDecoderBlock(256, 256)
        self.decoder1 = DDSCDecoderBlock(128, 128)
        self.decoder0 = DDSCDecoderBlock(64, 64)

        self.side11 = nn.Conv2d(64,out_ch,3,padding=1)
        self.side22 = nn.Conv2d(64,out_ch,3,padding=1)
        self.side33 = nn.Conv2d(128,out_ch,3,padding=1)
        self.side44 = nn.Conv2d(256,out_ch,3,padding=1)
        self.side55 = nn.Conv2d(512,out_ch,3,padding=1)
        self.side66 = nn.Conv2d(512,out_ch,3,padding=1)


        self.outconv = nn.Conv2d(6*out_ch,out_ch,1)


        self.up_conv = UpConv(64,64)
        self.up_conv_4 = UpConv(1, 1,4)
        self.conv_out = nn.Sequential(
            nn.Conv2d(64*2, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),  nn.ReLU(inplace=True)
        )
        self.sig = nn.Sigmoid()
        self.soft = nn.Softmax(dim=2)
        self.fuse_line = GASF([3,5,9]) # 上下图片融合 模块
        # self.channel_atten1 = channel_atten(64)
        # self.channel_atten2 = channel_atten(128)
        self.channel_atten3 = channel_atten(512)

    def forward(self, grey, color):
        ############################################  多光谱图像编码  #####################################################
        cx = color
        cx1 = self.stage1(cx)  # 128*128   64
        cx = self.pool12(cx1)
        cx2 = self.stage2(cx)  # 64*64     128
        cx = self.pool23(cx2)
        cx3 = self.stage3(cx)  # 32*32     256
        cx = self.pool34(cx3)
        cx4 = self.stage4(cx)  # 16*16     512
        cx = self.pool45(cx4)
        cx5 = self.stage5(cx)  # 8*8        512
        cx = self.pool56(cx5)
        cx6 = self.stage6(cx)  # 4*4        512

        side_512_cx, side_256_cx, side_128_cx = self.side1(self.side1s(cx1)), self.side2(self.side2s(cx2)), self.side3(self.side3s(cx3)) # 三个门控
        binary_128, binary_64, binary_32, binary_16, binary_8, binary_4 = map(self.soft,
                                                                              [side_512_cx, side_256_cx, side_128_cx, cx4, cx5, cx6])
        # 128 64 32是门控 通道为1  16 8 4用于后续融合 通道都是 512
        binary_128_512 = F.interpolate(binary_128, scale_factor=4, mode='bilinear', align_corners=True)
        # 2 1 512 512
        ############################################  全色图像编码  #####################################################
        gx = grey
        gx1 = self.stage11(gx)  # 512*512
        gx = self.pool12(gx1)
        gx2 = self.stage22(gx)  # 256*256
        gx = self.pool23(gx2)
        gx = gx * binary_128
        gx3 = self.stage3_my(gx, binary_128)  # 128*128
        gx = self.pool34(gx3)
        gx = gx * binary_64
        gx4 = self.stage4_my(gx, binary_64)  # 64*64
        gx = self.pool45(gx4)
        gx = gx * binary_32
        gx5 = self.stage5_my(gx, binary_32)  # 32*32
        gx = self.pool56(gx5)
        # 大图片的最后一层
        gx6 = self.fuse_line(gx, binary_16,binary_8,binary_4)  # 16*16 融合
        gx6 = self.channel_atten3(gx6) # 512 16 16
        # gx6up = _upsample_like(gx6, gx5)
        gx6up = self.decoder4(gx6) # 512 32 32
        ############################################  特征融合  #####################################################

        ############################################      解码     #####################################################
        gx5d = self.stage55d(torch.cat((gx6up, gx5), 1)) # 512 32 32
        # gx5dup = _upsample_like(gx5d, gx4)
        gx5dup = self.decoder3(gx5d,cx3) # 512 64 64
        gx4d = self.stage44d(torch.cat((gx5dup, gx4), 1)) # 256 64 64
        # gx4dup = _upsample_like(gx4d, gx3)
        gx4dup = self.decoder2(gx4d,cx2) # 256 128 128
        gx3d = self.stage33d(torch.cat((gx4dup, gx3), 1)) # 128 128 128
        # gx3dup = _upsample_like(gx3d, gx2)
        gx3dup = self.decoder1(gx3d) # 128 256 256
        gx2d = self.stage22d(torch.cat((gx3dup, gx2), 1))
        # gx2dup = _upsample_like(gx2d, gx1)
        gx2dup = self.decoder0(gx2d) # 64 512 512
        gx1d = self.stage11d(torch.cat((gx2dup, gx1), 1))
        # side output
        side_512, side_256, side_128, side_64, side_32, side_16 = self.side11(gx1d), self.side22(gx2d), self.side33(gx3d), \
                                                                  self.side44(gx4d), self.side55(gx5d), self.side66(gx6)
        side_256, side_128, side_64, side_32, side_16 = map(_upsample_like, *zip([side_256, side_512],
                                                                                 [side_128, side_512],
                                                                                 [side_64, side_512],
                                                                                 [side_32, side_512],
                                                                                 [side_16, side_512])) # 全部上采样到 1 512 512

        d0 = self.outconv(torch.cat((side_512, side_256, side_128, side_64, side_32, side_16), 1))

        m0, m1, m2, m3, m4, m5, m6 = map(self.sig, [d0, side_512, side_256, side_128, side_64, side_32, side_16])

        return m0, m1, m2, m3, m4, m5, m6, binary_128_512

class DDSCDecoderBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(DDSCDecoderBlock, self).__init__()
        self.deconv2 = nn.ConvTranspose2d(in_ch, in_ch // 2, 3, stride=2, padding=1, output_padding=1)
        self.norm2 = nn.BatchNorm2d(in_ch // 2)
        self.block1 = nn.Sequential(
            DSConv(in_ch // 2, in_ch // 2, kernel_size=3, extend_scope=1, morph=0, if_offset=True, device="cuda"),
            nn.BatchNorm2d(in_ch // 2))
        self.block2 = nn.Sequential(
            DSConv(in_ch // 2, in_ch // 2, kernel_size=5, extend_scope=1, morph=1, if_offset=True, device="cuda"),
            nn.BatchNorm2d(in_ch // 2))
        self.block3 = nn.Sequential(nn.Conv2d(in_ch // 2, in_ch // 2, kernel_size=7, padding=3, bias=False),
                                    nn.BatchNorm2d(in_ch // 2))
        self.conv3 = nn.Conv2d( 3*in_ch//2, out_ch, 1, bias=False)
        self.norm3 = nn.BatchNorm2d(out_ch)

    def forward(self, x):
        x = self.deconv2(x)
        x = nonlinearity(self.norm2(x))
        x1 = nonlinearity(self.block1(x))
        x2 = nonlinearity(self.block2(x))
        x3 = nonlinearity(self.block3(x))
        x = torch.cat((x1, x2, x3), 1)
        x = self.conv3(x)
        x = nonlinearity(self.norm3(x))
        return x

class TwoDSCDecoderBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(TwoDSCDecoderBlock, self).__init__()

        # 大图片的蛇形卷积
        self.dsc1x = DSConv(in_ch , in_ch , kernel_size=3, extend_scope=1, morph=0, if_offset=True, device="cuda")
        self.bn1x = nn.BatchNorm2d(in_ch)
        self.dsc1y = DSConv(in_ch, in_ch, kernel_size=3, extend_scope=1, morph=1, if_offset=True,device="cuda")
        self.bn1y = nn.BatchNorm2d(in_ch)
        # 小图片的蛇形卷积
        self.dsc2x = DSConv(in_ch // 2, in_ch // 2, kernel_size=5, extend_scope=1, morph=0, if_offset=True, device="cuda")
        self.bn2x = nn.BatchNorm2d(in_ch // 2)
        self.dsc2y = DSConv(in_ch // 2, in_ch // 2, kernel_size=5, extend_scope=1, morph=1, if_offset=True,device="cuda")
        self.bn2y = nn.BatchNorm2d(in_ch // 2)
        # 降维
        self.conv3 = nn.Conv2d( 6*in_ch//2, 3*in_ch//2, 1, bias=False)
        self.bn3 = nn.BatchNorm2d(3*in_ch//2)
        # 转置卷积上采样
        self.deconv2 = nn.ConvTranspose2d(3*in_ch//2, out_ch, 3, stride=2, padding=1, output_padding=1)
        self.bn4 = nn.BatchNorm2d(out_ch)

    def forward(self, x, y):
        x = self.dsc1x(x)
        x = self.bn1x(x)
        x = nonlinearity(x)
        h1 = x # 记录x用于后续残差
        x = self.dsc1y(x)
        x = self.bn1y(x)
        x = nonlinearity(x)


        y = self.dsc2x(y)
        y = self.bn2x(y)
        y = nonlinearity(y)
        h2 = y # 记录x用于后续残差
        y = self.dsc2y(y)
        y = self.bn2y(y)
        y = nonlinearity(y)

        x = torch.cat((h1, x , h2 , y), 1)
        x = self.conv3(x)
        x = self.bn3(x)
        x = nonlinearity(x)
        x = self.deconv2(x)
        x = self.bn4(x)
        x = nonlinearity(x)

        return x

class DSCConv(nn.Module):
    def __init__(self, in_ch,kernel_size):
        super(DSCConv, self).__init__()

        # 蛇形卷积操作
        self.dsc1x = DSConv(in_ch , in_ch , kernel_size=kernel_size, extend_scope=1, morph=0, if_offset=True, device="cuda")
        self.bn1x = nn.BatchNorm2d(in_ch)
        self.dsc1y = DSConv(in_ch, in_ch, kernel_size=3, extend_scope=1, morph=1, if_offset=True,device="cuda")
        self.bn1y = nn.BatchNorm2d(in_ch)

    def forward(self, x):
        x = self.dsc1x(x)
        x = self.bn1x(x)
        x = nonlinearity(x)
        x = self.dsc1y(x)
        x = self.bn1y(x)
        x = nonlinearity(x)

        return x