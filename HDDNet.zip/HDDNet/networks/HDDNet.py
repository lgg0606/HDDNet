"""
Codes of LinkNet based on https://github.com/snakers4/spacenet-three
"""
import einops
from typing import Union
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import models
import torch.nn.functional as F
from thop import profile
from functools import partial
from torch.nn import init
from einops import einops
from typing import Dict
from torchinfo import summary

nonlinearity = partial(F.relu, inplace=True)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class DSConv_pro(nn.Module):
    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 1,
        kernel_size: int = 9,
        extend_scope: float = 1.0,
        morph: int = 0,
        if_offset: bool = True,
        device = device,
    ):
        """
        A Dynamic Snake Convolution Implementation

        Based on:

            TODO

        Args:
            in_ch: number of input channels. Defaults to 1.
            out_ch: number of output channels. Defaults to 1.
            kernel_size: the size of kernel. Defaults to 9.
            extend_scope: the range to expand. Defaults to 1 for this method.
            extend_scope: 要扩展的范围。此方法默认为1。
            morph: the morphology of the convolution kernel is mainly divided into two types along the x-axis (0) and the y-axis (1) (see the paper for details).
            if_offset: whether deformation is required,  if it is False, it is the standard convolution kernel. Defaults to True.
            morph:,卷积核的形态主要分为沿x轴(0)和y轴(1)两种
            if_offset:是否需要变形，如果为False，则为标准卷积核。默认为True。
        """

        super().__init__()

        if morph not in (0, 1):
            raise ValueError("morph should be 0 or 1.")

        self.kernel_size = kernel_size
        self.extend_scope = extend_scope
        self.morph = morph
        self.if_offset = if_offset
        self.device = torch.device(device)
        self.to(device)

        # self.bn = nn.BatchNorm2d(2 * kernel_size)
        self.gn_offset = nn.GroupNorm(kernel_size, 2 * kernel_size)
        self.gn = nn.GroupNorm(out_channels // 4, out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.tanh = nn.Tanh()

        self.offset_conv = nn.Conv2d(in_channels, 2 * kernel_size, 3, padding=1)
        # self.offset_conv = nn.Sequential(
        #     nn.Conv2d(in_channels, in_channels, 3, padding=1, groups=in_channels),
        #     nn.Conv2d(in_channels, 2 * kernel_size, 1)
        # )

        self.dsc_conv_x = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(kernel_size, 1),
            stride=(kernel_size, 1),
            padding=0,
        )
        self.dsc_conv_y = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(1, kernel_size),
            stride=(1, kernel_size),
            padding=0,
        )

    def forward(self, input: torch.Tensor):
        # Predict offset map between [-1, 1]
        offset = self.offset_conv(input)
        # offset = self.bn(offset)
        offset = self.gn_offset(offset)
        offset = self.tanh(offset)

        # Run deformative conv
        y_coordinate_map, x_coordinate_map = get_coordinate_map_2D(
            offset=offset,
            morph=self.morph,
            extend_scope=self.extend_scope,
            device=self.device,
        )
        deformed_feature = get_interpolated_feature(
            input,
            y_coordinate_map,
            x_coordinate_map,
        )

        if self.morph == 0:
            output = self.dsc_conv_x(deformed_feature)
        elif self.morph == 1:
            output = self.dsc_conv_y(deformed_feature)

        # Groupnorm & ReLU
        output = self.gn(output)
        output = self.relu(output)

        return output


def get_coordinate_map_2D(
    offset: torch.Tensor,
    morph: int,
    extend_scope: float = 1.0,
    device: Union[str, torch.device] = "cuda",
):
    """Computing 2D coordinate map of DSCNet based on: TODO

    Args:
        offset: offset predict by network with shape [B, 2*K, W, H]. Here K refers to kernel size.
        morph: the morphology of the convolution kernel is mainly divided into two types along the x-axis (0) and the y-axis (1) (see the paper for details).
        extend_scope: the range to expand. Defaults to 1 for this method.
        device: location of data. Defaults to 'cuda'.

    Return:
        y_coordinate_map: coordinate map along y-axis with shape [B, K_H * H, K_W * W]
        x_coordinate_map: coordinate map along x-axis with shape [B, K_H * H, K_W * W]
    """

    if morph not in (0, 1):
        raise ValueError("morph should be 0 or 1.")

    batch_size, _, width, height = offset.shape
    kernel_size = offset.shape[1] // 2
    center = kernel_size // 2
    device = torch.device(device)

    y_offset_, x_offset_ = torch.split(offset, kernel_size, dim=1)

    y_center_ = torch.arange(0, width, dtype=torch.float32, device=device)
    y_center_ = einops.repeat(y_center_, "w -> k w h", k=kernel_size, h=height)

    x_center_ = torch.arange(0, height, dtype=torch.float32, device=device)
    x_center_ = einops.repeat(x_center_, "h -> k w h", k=kernel_size, w=width)

    if morph == 0:
        """
        Initialize the kernel and flatten the kernel
            y: only need 0
            x: -num_points//2 ~ num_points//2 (Determined by the kernel size)
        """
        y_spread_ = torch.zeros([kernel_size], device=device)
        x_spread_ = torch.linspace(-center, center, kernel_size, device=device)

        y_grid_ = einops.repeat(y_spread_, "k -> k w h", w=width, h=height)
        x_grid_ = einops.repeat(x_spread_, "k -> k w h", w=width, h=height)

        y_new_ = y_center_ + y_grid_
        x_new_ = x_center_ + x_grid_

        y_new_ = einops.repeat(y_new_, "k w h -> b k w h", b=batch_size)
        x_new_ = einops.repeat(x_new_, "k w h -> b k w h", b=batch_size)

        y_offset_ = einops.rearrange(y_offset_, "b k w h -> k b w h")
        y_offset_new_ = y_offset_.detach().clone()

        # The center position remains unchanged and the rest of the positions begin to swing
        # This part is quite simple. The main idea is that "offset is an iterative process"

        y_offset_new_[center] = 0

        for index in range(1, center + 1):
            y_offset_new_[center + index] = (
                y_offset_new_[center + index - 1] + y_offset_[center + index]
            )
            y_offset_new_[center - index] = (
                y_offset_new_[center - index + 1] + y_offset_[center - index]
            )

        y_offset_new_ = einops.rearrange(y_offset_new_, "k b w h -> b k w h")

        y_new_ = y_new_.add(y_offset_new_.mul(extend_scope))

        y_coordinate_map = einops.rearrange(y_new_, "b k w h -> b (w k) h")
        x_coordinate_map = einops.rearrange(x_new_, "b k w h -> b (w k) h")

    elif morph == 1:
        """
        Initialize the kernel and flatten the kernel
            y: -num_points//2 ~ num_points//2 (Determined by the kernel size)
            x: only need 0
        """
        y_spread_ = torch.linspace(-center, center, kernel_size, device=device)
        x_spread_ = torch.zeros([kernel_size], device=device)

        y_grid_ = einops.repeat(y_spread_, "k -> k w h", w=width, h=height)
        x_grid_ = einops.repeat(x_spread_, "k -> k w h", w=width, h=height)

        y_new_ = y_center_ + y_grid_
        x_new_ = x_center_ + x_grid_

        y_new_ = einops.repeat(y_new_, "k w h -> b k w h", b=batch_size)
        x_new_ = einops.repeat(x_new_, "k w h -> b k w h", b=batch_size)

        x_offset_ = einops.rearrange(x_offset_, "b k w h -> k b w h")
        x_offset_new_ = x_offset_.detach().clone()

        # The center position remains unchanged and the rest of the positions begin to swing
        # This part is quite simple. The main idea is that "offset is an iterative process"

        x_offset_new_[center] = 0

        for index in range(1, center + 1):
            x_offset_new_[center + index] = (
                x_offset_new_[center + index - 1] + x_offset_[center + index]
            )
            x_offset_new_[center - index] = (
                x_offset_new_[center - index + 1] + x_offset_[center - index]
            )

        x_offset_new_ = einops.rearrange(x_offset_new_, "k b w h -> b k w h")

        x_new_ = x_new_.add(x_offset_new_.mul(extend_scope))

        y_coordinate_map = einops.rearrange(y_new_, "b k w h -> b w (h k)")
        x_coordinate_map = einops.rearrange(x_new_, "b k w h -> b w (h k)")

    return y_coordinate_map, x_coordinate_map


def get_interpolated_feature(
    input_feature: torch.Tensor,
    y_coordinate_map: torch.Tensor,
    x_coordinate_map: torch.Tensor,
    interpolate_mode: str = "bilinear",
):
    """From coordinate map interpolate feature of DSCNet based on: TODO

    Args:
        input_feature: feature that to be interpolated with shape [B, C, H, W]
        y_coordinate_map: coordinate map along y-axis with shape [B, K_H * H, K_W * W]
        x_coordinate_map: coordinate map along x-axis with shape [B, K_H * H, K_W * W]
        interpolate_mode: the arg 'mode' of nn.functional.grid_sample, can be 'bilinear' or 'bicubic' . Defaults to 'bilinear'.

    Return:
        interpolated_feature: interpolated feature with shape [B, C, K_H * H, K_W * W]
    """

    if interpolate_mode not in ("bilinear", "bicubic"):
        raise ValueError("interpolate_mode should be 'bilinear' or 'bicubic'.")

    y_max = input_feature.shape[-2] - 1
    x_max = input_feature.shape[-1] - 1

    y_coordinate_map_ = _coordinate_map_scaling(y_coordinate_map, origin=[0, y_max])
    x_coordinate_map_ = _coordinate_map_scaling(x_coordinate_map, origin=[0, x_max])

    y_coordinate_map_ = torch.unsqueeze(y_coordinate_map_, dim=-1)
    x_coordinate_map_ = torch.unsqueeze(x_coordinate_map_, dim=-1)

    # Note here grid with shape [B, H, W, 2]
    # Where [:, :, :, 2] refers to [x ,y]
    grid = torch.cat([x_coordinate_map_, y_coordinate_map_], dim=-1)

    interpolated_feature = nn.functional.grid_sample(
        input=input_feature,
        grid=grid,
        mode=interpolate_mode,
        padding_mode="zeros",
        align_corners=True,
    )

    return interpolated_feature


def _coordinate_map_scaling(
    coordinate_map: torch.Tensor,
    origin: list,
    target: list = [-1, 1],
):
    """Map the value of coordinate_map from origin=[min, max] to target=[a,b] for DSCNet based on: TODO

    Args:
        coordinate_map: the coordinate map to be scaled
        origin: original value range of coordinate map, e.g. [coordinate_map.min(), coordinate_map.max()]
        target: target value range of coordinate map,Defaults to [-1, 1]

    Return:
        coordinate_map_scaled: the coordinate map after scaling
    """
    min, max = origin
    a, b = target

    coordinate_map_scaled = torch.clamp(coordinate_map, min, max)

    scale_factor = (b - a) / (max - min)
    coordinate_map_scaled = a + scale_factor * (coordinate_map_scaled - min)

    return coordinate_map_scaled


class MDecoderBlock(nn.Module):
    def __init__(self, in_channels, n_filters,dilation):
        super(MDecoderBlock, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels // 4, 1)
        self.norm1 = nn.BatchNorm2d(in_channels // 4)
        self.relu1 = nonlinearity

        self.deconv2 = nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 3, stride=2, padding=1, output_padding=1)
        self.norm2 = nn.BatchNorm2d(in_channels // 4)
        self.relu2 = nonlinearity

        self.gba = DSGD(in_channels // 4, n_filters)


    def forward(self, x):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)
        x = self.deconv2(x)
        x = self.norm2(x)
        x = self.relu2(x)
        x =self.gba(x)

        return x


class ADecoderBlock(nn.Module):
    def __init__(self, in_channels, n_filters ,dilation):
        super(ADecoderBlock, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels // 4, 1)
        self.norm1 = nn.BatchNorm2d(in_channels // 4)
        self.relu1 = nonlinearity

        self.deconv2 = nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 3, stride=2, padding=1, output_padding=1)
        self.norm2 = nn.BatchNorm2d(in_channels // 4)
        self.relu2 = nonlinearity

        self.Sconv2 = MCBE(in_channels//4, 4)

        self.conv3 = nn.Conv2d(in_channels //4, n_filters, 1)
        self.norm3 = nn.BatchNorm2d(n_filters)
        self.relu3 = nonlinearity


    def forward(self, x):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)
        x = self.deconv2(x)
        x = self.norm2(x)
        x = self.relu2(x)
        x = self.Sconv2(x)

        x = self.conv3(x)
        x = self.norm3(x)
        x = self.relu3(x)


        return x



class DSGD(nn.Module):
    def __init__(self, dim, out, k_size=3, d_list=[1,3,5,7]):
        super().__init__()
        self.dsconvx = DSConv_pro(dim, dim, 9, 1, 0)
        self.dsconvy = DSConv_pro(dim, dim, 9, 1, 1)

        self.pre_project = nn.Conv2d(dim, dim, 1)
        group_size = dim*3 // 4
        self.g0 = nn.Sequential(


            nn.Conv2d(group_size , group_size , kernel_size=3, stride=1,
                      padding=1,
                      dilation=d_list[0] )
        )
        self.g1 = nn.Sequential(

            nn.Conv2d(group_size , group_size , kernel_size=3, stride=1,
                      padding=3,
                      dilation=d_list[1])
        )
        self.g2 = nn.Sequential(


            nn.Conv2d(group_size , group_size , kernel_size=3, stride=1,
                      padding=5,
                      dilation=d_list[2] )
        )
        self.g3 = nn.Sequential(


            nn.Conv2d(group_size , group_size , kernel_size=3, stride=1,
                      padding=7,
                      dilation=d_list[3])
        )
        self.tail_conv = nn.Sequential(

            nn.Conv2d(dim * 3 , out, 1),

        )
    def forward(self, x):

        dx1 = self.dsconvx(x)
        dy1 = self.dsconvy(x)
        dx = torch.chunk(dx1, 4, dim=1)
        dy = torch.chunk(dy1, 4, dim=1)
        idx = torch.chunk(x, 4, dim=1)
        x0 = self.g0(torch.cat((dx[0],dy[0],idx[0]), dim=1))
        #print(x0.shape)
        x1 = self.g1(torch.cat((dx[1],dy[1],idx[1]), dim=1))
        #print(x1.shape)
        x2 = self.g2(torch.cat((dx[2],dy[2],idx[2]), dim=1))
        #print(x2.shape)
        x3 = self.g3(torch.cat((dx[3],dy[3],idx[3]), dim=1))
        #print(x3.shape)
        x = torch.cat((x0,x1,x2,x3), dim=1)
        x = self.tail_conv(x)
        return x




class MCBE(nn.Module):
    def __init__(self, in_channels, dilation):
        super(MCBE, self).__init__()

        # 原始方向卷积层定义
        self.deconv1 = nn.Conv2d(
            in_channels, in_channels // 4, (1, dilation * 2 + 1),
            padding=(0, dilation)
        )
        self.deconv2 = nn.Conv2d(
            in_channels, in_channels // 4, (dilation * 2 + 1, 1),
            padding=(dilation, 0)
        )
        self.deconv3 = nn.Conv2d(
            in_channels, in_channels // 4, (dilation * 2 + 1, 1),
            padding=(dilation, 0)
        )
        self.deconv4 = nn.Conv2d(
            in_channels, in_channels // 4, (1, dilation * 2 + 1),
            padding=(0, dilation)
        )

        # 定义Sobel滤波器核
        self._init_sobel_kernels(in_channels // 4)

        # 每个分支的BN层和3x3卷积
        for i in range(4):
            setattr(self, f'bn{i + 1}', nn.BatchNorm2d(in_channels // 4))
            setattr(self, f'conv{i + 1}',
                    nn.Conv2d(in_channels // 4, in_channels // 4, 3, padding=1))

    def _init_sobel_kernels(self, channels):
        # 定义四个方向的Sobel核
        kernels = [
            # Sobel_x (垂直边缘)
            [[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]],
            # Sobel_y (水平边缘)
            [[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]],
            # Sobel_45
            [[[-2, -1, 0], [-1, 0, 1], [0, 1, 2]]],
            # Sobel_135
            [[[0, 1, 2], [-1, 0, 1], [-2, -1, 0]]]
        ]

        # 创建分组卷积层
        for i in range(4):
            kernel = torch.tensor(kernels[i], dtype=torch.float32)
            kernel = kernel.repeat(channels, 1, 1, 1)  # 扩展通道数
            conv = nn.Conv2d(channels, channels, 3, padding=1,
                             groups=channels, bias=False)
            conv.weight.data = kernel
            conv.weight.requires_grad = False
            setattr(self, f'sobel{i + 1}', conv)

    def forward(self, x):
        # 处理四个分支
        x1 = self._process_branch(x, self.deconv1, self.sobel1, self.bn1, self.conv1)
        x2 = self._process_branch(x, self.deconv2, self.sobel2, self.bn2, self.conv2)

        # 处理对角线分支
        x3 = self._process_diag(
            x, self.deconv3, self.sobel3, self.bn3, self.conv3,
            self.h_transform, self.inv_h_transform
        )
        x4 = self._process_diag(
            x, self.deconv4, self.sobel4, self.bn4, self.conv4,
            self.v_transform, self.inv_v_transform
        )

        return torch.cat([x1, x2, x3, x4], dim=1)

    def _process_branch(self, x, deconv, sobel, bn, conv):
        x1 = deconv(x)
        x = sobel(x1)
        x = bn(x)
        x = F.relu(x, inplace=True)
        return conv(x) +x1

    def _process_diag(self, x, deconv, sobel, bn, conv, transform, inv_transform):
        x = transform(x)
        x = deconv(x)
        x1 = inv_transform(x)
        x = sobel(x1)
        x = bn(x)
        x = F.relu(x, inplace=True)
        return conv(x) + x1

    # 保持原有的空间变换方法
    def h_transform(self, x):
        shape = x.size()
        x = F.pad(x, (0, shape[-1]))
        x = x.reshape(shape[0], shape[1], -1)[..., :-shape[-1]]
        return x.reshape(shape[0], shape[1], shape[2], 2 * shape[3] - 1)

    def inv_h_transform(self, x):
        shape = x.size()
        x = x.reshape(shape[0], shape[1], -1)
        x = F.pad(x, (0, shape[-2]))
        x = x.reshape(shape[0], shape[1], shape[-2], 2 * shape[-2])
        return x[..., 0:shape[-2]]

    def v_transform(self, x):
        x = x.permute(0, 1, 3, 2)
        shape = x.size()
        x = F.pad(x, (0, shape[-1]))
        x = x.reshape(shape[0], shape[1], -1)[..., :-shape[-1]]
        return x.reshape(shape[0], shape[1], shape[2], 2 * shape[3] - 1).permute(0, 1, 3, 2)

    def inv_v_transform(self, x):
        x = x.permute(0, 1, 3, 2)
        shape = x.size()
        x = x.reshape(shape[0], shape[1], -1)
        x = F.pad(x, (0, shape[-2]))
        x = x.reshape(shape[0], shape[1], shape[-2], 2 * shape[-2])
        return x[..., 0:shape[-2]].permute(0, 1, 3, 2)


class DAFF(nn.Module):
    def __init__(self, embed_dim, mlp_ratio=4):
        super().__init__()
        hidden_dim = embed_dim // mlp_ratio

        # 空间注意力模块
        self.spatial = nn.Sequential(
            nn.Conv2d(embed_dim, 1, kernel_size=1, padding=0),
            nn.Sigmoid()
        )

        # 通道注意力部分
        self.mlp = nn.Sequential(
            nn.Conv2d(embed_dim, hidden_dim, kernel_size=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim, embed_dim, kernel_size=1, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x, y):
        # 空间注意力权重
        spatial_weight = self.spatial(x + y)  # [B,1,H,W]

        x1 = x + x * spatial_weight
        y1 = y + y * spatial_weight

        xy = x1 + y1  # [B,C,H,W]

        # 池化
        avg_pool = F.adaptive_avg_pool2d(xy, 1)  # [B,C,1,1]
        max_pool = F.adaptive_max_pool2d(xy, 1)  # [B,C,1,1]

        # 特征相加
        channel_descriptor = avg_pool + max_pool  # [B,C,1,1]

        channel_weight = self.mlp(channel_descriptor)  # [B,C,1,1]

        # 加权融合
        x2 = x + x1 * channel_weight
        y2 = y + y1 * channel_weight

        return x2 + y2



class HDD(nn.Module):
    def __init__(self, num_classes=1, num_channels=3):
        super(HDD, self).__init__()

        dilation = [1, 2, 3, 4]
        d = [32,64,128,256]
        filters = [64, 128, 256, 512]
        resnet = models.resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.encoder3 = resnet.layer3
        self.encoder4 = resnet.layer4




        self.decoder4 = DecoderBlock(filters[3], filters[2], dilation=dilation[3])
        self.decoder3 = DecoderBlock(filters[2], filters[1], dilation=dilation[2])
        self.decoder2 = DecoderBlock(filters[1], filters[0], dilation=dilation[1])
        self.decoder1 = DecoderBlock(filters[0], filters[0], dilation=dilation[0])

        # 使用新定义的 MDecoderBlock
        self.mdecoder4 = MDecoderBlock(filters[3], filters[2], dilation=d[0])
        self.mdecoder3 = MDecoderBlock(filters[2], filters[1], dilation=d[1])
        self.mdecoder2 = MDecoderBlock(filters[1], filters[0], dilation=d[2])
        self.mdecoder1 = MDecoderBlock(filters[0], filters[0], dilation=d[3])

        self.daff = DAFF(filters[0])


        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x = self.firstmaxpool(x)
        e1 = self.encoder1(x)
        e2 = self.encoder2(e1)
        e3 = self.encoder3(e2)
        e4 = self.encoder4(e3)



        # MDecoder
        md4 = self.mdecoder4(e4) + e3
        md3 = self.mdecoder3(md4) + e2
        md2 = self.mdecoder2(md3) + e1
        md1 = self.mdecoder1(md2)

        # Decoder
        ##d4 = self.decoder4(e4) + e3
        d3 = self.decoder3(e3) + e2
        d2 = self.decoder2(d3) + e1
        d1 = self.decoder1(d2)

        #out = self.iaf(md1, d1)
        out = self.daff(md1,d1)

        out = self.finaldeconv1(out)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)

        return F.sigmoid(out)



from torchinfo import summary
if __name__ == '__main__':
    alexnet1 = HDD().cuda()  # 通道数等于输入图片的通道数
    # print(alexnet1)
    # test1 = torch.ones(1,3, 1024, 1024)  # 输入64batch  3通道 120*120的图片
    #alexnet1.eval()  # 添加这一行
    summary(alexnet1, input_size=(1, 3, 512, 512))  # 直接输出参数量和计算量
    # flops, params = profile(alexnet1, (test1))
    # print('flops: %.2f G, params: %.2f M' % (flops / 1000000.0 / 1024.0, params / 1000000.0))
    # test1 = alexnet1(test1)
    # print(test1.shape)  # 输出无变化
    # print(f"数值范围：[{test1.min():.3f},  {test1.max():.3f}]")  # 应在0-1之间


