import torch
import torch.nn as nn
import torch.utils.data as data
from torch.autograd import Variable as V
import matplotlib.pyplot as plt
import cv2
import os
import numpy as np
import tqdm
from time import time
from sklearn.metrics import confusion_matrix
from networks.OARENet.networks.testNet import SwinT_OAM


from framework import MyFrame
from loss import dice_bce_loss
from data import ImageFolder

import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '0'
os.environ['TORCH_USE_CUDA_DSA'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
torch.backends.cudnn.enabled = True #寻找适合硬件的最佳算法,加上这一行运行时间能缩短很多!!!


SHAPE = (1024,1024)

ROOT = 'D:/CVdata/Ottawa/train2/' # 改成你数据集的地址
#D:/CVdata/CHN6/train-20240329T094659Z-001/train2/
#D:/CVdata/Ottawa/train2/
#D:/CVdata/DeepGlobe/train/
#D:/CVdata/Massachusetts/train3/
# VALID_ROOT = '/root/autodl-tmp/deepglobe_test/valid/' # 修改验证集路径
imagelist = filter(lambda x: x.find('sat')!=-1, os.listdir(ROOT))
trainlist = list(map(lambda x: x[:-8], imagelist)) # 加载训练集
# imagelist1 = filter(lambda x: x.find('sat')!=-1, os.listdir(VALID_ROOT))

# vaildlist = list(map(lambda x: x[:-8], imagelist1)) # 加载测试集

NAME = 'SwinT_OA'
# BATCHSIZE_PER_CARD = 4

solver = MyFrame(SwinT_OAM, dice_bce_loss, 2e-4)
# batchsize = torch.cuda.device_count() * BATCHSIZE_PER_CARD
batchsize = 4

dataset = ImageFolder(trainlist, ROOT)
# valid_dataset = ImageFolder(vaildlist, VALID_ROOT) # 加载验证集
data_loader = torch.utils.data.DataLoader(
    dataset,
    batch_size=batchsize,
    shuffle=True,
    num_workers=0) # 多GPU问题
# valid_data_loader = torch.utils.data.DataLoader(
#     valid_dataset, # 使用验证集
#     batch_size=batchsize,
#     shuffle=False, # 不需要shuffle验证集
#     num_workers=0)

mylog = open('logs/'+NAME+'.log','w')
tic = time()
no_optim = 0
total_epoch = 100
train_epoch_best_loss = 100

train_losses = []  # 用于记录损失函数变化的列表
valid_losses = []  # 用于记录验证集损失函数变化的列表
for epoch in range(1, total_epoch + 1):
    data_loader_iter = iter(data_loader)
    train_epoch_loss = 0
    progress_bar = tqdm.tqdm(data_loader_iter, desc='Epoch {:d}'.format(epoch), dynamic_ncols=True)  # 添加进度条
    for i, (img, mask) in enumerate(progress_bar):  # 修改这里
        solver.set_input(img, mask)
        train_loss = solver.optimize()
        train_epoch_loss += train_loss
        progress_bar.set_postfix(train_loss=train_loss)  # 更新进度条信息
    train_epoch_loss /= len(data_loader)

    # valid_data_loader_iter = iter(valid_data_loader)  # 验证集迭代器
    # valid_epoch_loss = 0
    # progress_bar1 = tqdm.tqdm(valid_data_loader_iter, desc='Epoch {:d}'.format(epoch), dynamic_ncols=True)  # 添加进度条
    # for i, (img, mask) in enumerate(progress_bar1):
    #     solver.set_input(img, mask)
    #     try:
    #         valid_loss = solver.forward()
    #         valid_epoch_loss += valid_loss
    #     except Exception as e:
    #         # print(f"Error in computing validation loss: {e}")
    #         continue
    #     progress_bar1.set_postfix(valid_loss=valid_loss)  # 更新进度条信息
    # valid_epoch_loss /= len(valid_data_loader_iter)

    # 记录损失函数变化
    train_losses.append(train_epoch_loss)
    # valid_losses.append(valid_epoch_loss)
    print('********', file=mylog)
    print('epoch:', epoch, '    time:', int(time() - tic), file=mylog)
    print('train_loss:', train_epoch_loss, file=mylog)
    print('SHAPE:', SHAPE, file=mylog)
    print('********')
    print('epoch:', epoch, '    time:', int(time() - tic))
    print('train_loss:', train_epoch_loss)
    print('SHAPE:', SHAPE)


    if train_epoch_loss >= train_epoch_best_loss:
        no_optim += 1
    else:
        no_optim = 0
        train_epoch_best_loss = train_epoch_loss
        solver.save('weights/' + NAME + '.th')

    
    if epoch == int(total_epoch / 2):
        # solver.load('weights/'+NAME+'.th')
        solver.save('weights/' + NAME + str(epoch) + '.th')
        solver.update_lr(5.0, factor=True, mylog=mylog)

    if epoch == int(total_epoch * 0.85):
        # solver.save('weights/'+NAME+str(epoch)+'.th')
        # solver.load('weights/'+NAME+'.th')
        solver.update_lr(5.0, factor=True, mylog=mylog)

    if epoch == int(total_epoch * 0.95):
        # solver.save('weights/'+NAME+str(epoch)+'.th')
        # solver.load('weights/'+NAME+'.th')
        solver.update_lr(5.0, factor=True, mylog=mylog)
    mylog.flush()



# 绘制损失函数变化图
plt.plot(range(1, len(train_losses) + 1), train_losses)
plt.title('Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.savefig('train_loss.png')
plt.show()
# plt.plot(range(1, len(valid_losses) + 1), valid_losses)
# plt.title('validing Loss')
# plt.xlabel('Epoch')
# plt.ylabel('Loss')
# plt.savefig('val_loss.png')
# plt.show()

print('Finish!', file=mylog)
print('Finish!')
mylog.close()








