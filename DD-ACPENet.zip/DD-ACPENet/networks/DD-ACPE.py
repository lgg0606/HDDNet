"""
Codes of LinkNet based on https://github.com/snakers4/spacenet-three
"""
import einops
from typing import Union
import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import models
import torch.nn.functional as F
from thop import profile
from functools import partial
from torch.nn import init
from einops import einops
from typing import Dict
#from torchinfo import summary

nonlinearity = partial(F.relu, inplace=True)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class DSConv_pro(nn.Module):
    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 1,
        kernel_size: int = 9,
        extend_scope: float = 1.0,
        morph: int = 0,
        if_offset: bool = True,
        device = "cpu",
    ):
        """
        A Dynamic Snake Convolution Implementation

        Based on:

            TODO

        Args:
            in_ch: number of input channels. Defaults to 1.
            out_ch: number of output channels. Defaults to 1.
            kernel_size: the size of kernel. Defaults to 9.
            extend_scope: the range to expand. Defaults to 1 for this method.
            extend_scope: 要扩展的范围。此方法默认为1。
            morph: the morphology of the convolution kernel is mainly divided into two types along the x-axis (0) and the y-axis (1) (see the paper for details).
            if_offset: whether deformation is required,  if it is False, it is the standard convolution kernel. Defaults to True.
            morph:,卷积核的形态主要分为沿x轴(0)和y轴(1)两种
            if_offset:是否需要变形，如果为False，则为标准卷积核。默认为True。
        """

        super().__init__()

        if morph not in (0, 1):
            raise ValueError("morph should be 0 or 1.")

        self.kernel_size = kernel_size
        self.extend_scope = extend_scope
        self.morph = morph
        self.if_offset = if_offset
        self.device = torch.device(device)
        self.to(device)

        # self.bn = nn.BatchNorm2d(2 * kernel_size)
        self.gn_offset = nn.GroupNorm(kernel_size, 2 * kernel_size)
        self.gn = nn.GroupNorm(out_channels // 4, out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.tanh = nn.Tanh()

        self.offset_conv = nn.Conv2d(in_channels, 2 * kernel_size, 3, padding=1)
        # self.offset_conv = nn.Sequential(
        #     nn.Conv2d(in_channels, in_channels, 3, padding=1, groups=in_channels),
        #     nn.Conv2d(in_channels, 2 * kernel_size, 1)
        # )

        self.dsc_conv_x = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(kernel_size, 1),
            stride=(kernel_size, 1),
            padding=0,
        )
        self.dsc_conv_y = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(1, kernel_size),
            stride=(1, kernel_size),
            padding=0,
        )

    def forward(self, input: torch.Tensor):
        # Predict offset map between [-1, 1]
        offset = self.offset_conv(input)
        # offset = self.bn(offset)
        offset = self.gn_offset(offset)
        offset = self.tanh(offset)

        # Run deformative conv
        y_coordinate_map, x_coordinate_map = get_coordinate_map_2D(
            offset=offset,
            morph=self.morph,
            extend_scope=self.extend_scope,
            device=self.device,
        )
        deformed_feature = get_interpolated_feature(
            input,
            y_coordinate_map,
            x_coordinate_map,
        )

        if self.morph == 0:
            output = self.dsc_conv_x(deformed_feature)
        elif self.morph == 1:
            output = self.dsc_conv_y(deformed_feature)

        # Groupnorm & ReLU
        output = self.gn(output)
        output = self.relu(output)

        return output


def get_coordinate_map_2D(
    offset: torch.Tensor,
    morph: int,
    extend_scope: float = 1.0,
    device: Union[str, torch.device] = "cuda",
):
    """Computing 2D coordinate map of DSCNet based on: TODO

    Args:
        offset: offset predict by network with shape [B, 2*K, W, H]. Here K refers to kernel size.
        morph: the morphology of the convolution kernel is mainly divided into two types along the x-axis (0) and the y-axis (1) (see the paper for details).
        extend_scope: the range to expand. Defaults to 1 for this method.
        device: location of data. Defaults to 'cuda'.

    Return:
        y_coordinate_map: coordinate map along y-axis with shape [B, K_H * H, K_W * W]
        x_coordinate_map: coordinate map along x-axis with shape [B, K_H * H, K_W * W]
    """

    if morph not in (0, 1):
        raise ValueError("morph should be 0 or 1.")

    batch_size, _, width, height = offset.shape
    kernel_size = offset.shape[1] // 2
    center = kernel_size // 2
    device = torch.device(device)

    y_offset_, x_offset_ = torch.split(offset, kernel_size, dim=1)

    y_center_ = torch.arange(0, width, dtype=torch.float32, device=device)
    y_center_ = einops.repeat(y_center_, "w -> k w h", k=kernel_size, h=height)

    x_center_ = torch.arange(0, height, dtype=torch.float32, device=device)
    x_center_ = einops.repeat(x_center_, "h -> k w h", k=kernel_size, w=width)

    if morph == 0:
        """
        Initialize the kernel and flatten the kernel
            y: only need 0
            x: -num_points//2 ~ num_points//2 (Determined by the kernel size)
        """
        y_spread_ = torch.zeros([kernel_size], device=device)
        x_spread_ = torch.linspace(-center, center, kernel_size, device=device)

        y_grid_ = einops.repeat(y_spread_, "k -> k w h", w=width, h=height)
        x_grid_ = einops.repeat(x_spread_, "k -> k w h", w=width, h=height)

        y_new_ = y_center_ + y_grid_
        x_new_ = x_center_ + x_grid_

        y_new_ = einops.repeat(y_new_, "k w h -> b k w h", b=batch_size)
        x_new_ = einops.repeat(x_new_, "k w h -> b k w h", b=batch_size)

        y_offset_ = einops.rearrange(y_offset_, "b k w h -> k b w h")
        y_offset_new_ = y_offset_.detach().clone()

        # The center position remains unchanged and the rest of the positions begin to swing
        # This part is quite simple. The main idea is that "offset is an iterative process"

        y_offset_new_[center] = 0

        for index in range(1, center + 1):
            y_offset_new_[center + index] = (
                y_offset_new_[center + index - 1] + y_offset_[center + index]
            )
            y_offset_new_[center - index] = (
                y_offset_new_[center - index + 1] + y_offset_[center - index]
            )

        y_offset_new_ = einops.rearrange(y_offset_new_, "k b w h -> b k w h")

        y_new_ = y_new_.add(y_offset_new_.mul(extend_scope))

        y_coordinate_map = einops.rearrange(y_new_, "b k w h -> b (w k) h")
        x_coordinate_map = einops.rearrange(x_new_, "b k w h -> b (w k) h")

    elif morph == 1:
        """
        Initialize the kernel and flatten the kernel
            y: -num_points//2 ~ num_points//2 (Determined by the kernel size)
            x: only need 0
        """
        y_spread_ = torch.linspace(-center, center, kernel_size, device=device)
        x_spread_ = torch.zeros([kernel_size], device=device)

        y_grid_ = einops.repeat(y_spread_, "k -> k w h", w=width, h=height)
        x_grid_ = einops.repeat(x_spread_, "k -> k w h", w=width, h=height)

        y_new_ = y_center_ + y_grid_
        x_new_ = x_center_ + x_grid_

        y_new_ = einops.repeat(y_new_, "k w h -> b k w h", b=batch_size)
        x_new_ = einops.repeat(x_new_, "k w h -> b k w h", b=batch_size)

        x_offset_ = einops.rearrange(x_offset_, "b k w h -> k b w h")
        x_offset_new_ = x_offset_.detach().clone()

        # The center position remains unchanged and the rest of the positions begin to swing
        # This part is quite simple. The main idea is that "offset is an iterative process"

        x_offset_new_[center] = 0

        for index in range(1, center + 1):
            x_offset_new_[center + index] = (
                x_offset_new_[center + index - 1] + x_offset_[center + index]
            )
            x_offset_new_[center - index] = (
                x_offset_new_[center - index + 1] + x_offset_[center - index]
            )

        x_offset_new_ = einops.rearrange(x_offset_new_, "k b w h -> b k w h")

        x_new_ = x_new_.add(x_offset_new_.mul(extend_scope))

        y_coordinate_map = einops.rearrange(y_new_, "b k w h -> b w (h k)")
        x_coordinate_map = einops.rearrange(x_new_, "b k w h -> b w (h k)")

    return y_coordinate_map, x_coordinate_map


def get_interpolated_feature(
    input_feature: torch.Tensor,
    y_coordinate_map: torch.Tensor,
    x_coordinate_map: torch.Tensor,
    interpolate_mode: str = "bilinear",
):
    """From coordinate map interpolate feature of DSCNet based on: TODO

    Args:
        input_feature: feature that to be interpolated with shape [B, C, H, W]
        y_coordinate_map: coordinate map along y-axis with shape [B, K_H * H, K_W * W]
        x_coordinate_map: coordinate map along x-axis with shape [B, K_H * H, K_W * W]
        interpolate_mode: the arg 'mode' of nn.functional.grid_sample, can be 'bilinear' or 'bicubic' . Defaults to 'bilinear'.

    Return:
        interpolated_feature: interpolated feature with shape [B, C, K_H * H, K_W * W]
    """

    if interpolate_mode not in ("bilinear", "bicubic"):
        raise ValueError("interpolate_mode should be 'bilinear' or 'bicubic'.")

    y_max = input_feature.shape[-2] - 1
    x_max = input_feature.shape[-1] - 1

    y_coordinate_map_ = _coordinate_map_scaling(y_coordinate_map, origin=[0, y_max])
    x_coordinate_map_ = _coordinate_map_scaling(x_coordinate_map, origin=[0, x_max])

    y_coordinate_map_ = torch.unsqueeze(y_coordinate_map_, dim=-1)
    x_coordinate_map_ = torch.unsqueeze(x_coordinate_map_, dim=-1)

    # Note here grid with shape [B, H, W, 2]
    # Where [:, :, :, 2] refers to [x ,y]
    grid = torch.cat([x_coordinate_map_, y_coordinate_map_], dim=-1)

    interpolated_feature = nn.functional.grid_sample(
        input=input_feature,
        grid=grid,
        mode=interpolate_mode,
        padding_mode="zeros",
        align_corners=True,
    )

    return interpolated_feature


def _coordinate_map_scaling(
    coordinate_map: torch.Tensor,
    origin: list,
    target: list = [-1, 1],
):
    """Map the value of coordinate_map from origin=[min, max] to target=[a,b] for DSCNet based on: TODO

    Args:
        coordinate_map: the coordinate map to be scaled
        origin: original value range of coordinate map, e.g. [coordinate_map.min(), coordinate_map.max()]
        target: target value range of coordinate map,Defaults to [-1, 1]

    Return:
        coordinate_map_scaled: the coordinate map after scaling
    """
    min, max = origin
    a, b = target

    coordinate_map_scaled = torch.clamp(coordinate_map, min, max)

    scale_factor = (b - a) / (max - min)
    coordinate_map_scaled = a + scale_factor * (coordinate_map_scaled - min)

    return coordinate_map_scaled

# 通道注意力模块
class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 自适应平均池化
        self.max_pool = nn.AdaptiveMaxPool2d(1)  # 自适应最大池化

        # 两个卷积层用于从池化后的特征中学习注意力权重
        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)  # 第一个卷积层，降维
        self.relu1 = nn.ReLU()  # ReLU激活函数
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)  # 第二个卷积层，升维
        self.sigmoid = nn.Sigmoid()  # Sigmoid函数生成最终的注意力权重

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))  # 对平均池化的特征进行处理
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))  # 对最大池化的特征进行处理
        out = avg_out + max_out  # 将两种池化的特征加权和作为输出
        return self.sigmoid(out)  # 使用sigmoid激活函数计算注意力权重

# 空间注意力模块
class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'  # 核心大小只能是3或7
        padding = 3 if kernel_size == 7 else 1  # 根据核心大小设置填充

        # 卷积层用于从连接的平均池化和最大池化特征图中学习空间注意力权重
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()  # Sigmoid函数生成最终的注意力权重

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)  # 对输入特征图执行平均池化
        max_out, _ = torch.max(x, dim=1, keepdim=True)  # 对输入特征图执行最大池化
        x = torch.cat([avg_out, max_out], dim=1)  # 将两种池化的特征图连接起来
        x = self.conv1(x)  # 通过卷积层处理连接后的特征图
        return self.sigmoid(x)  # 使用sigmoid激活函数计算注意力权重

# CBAM模块
class CBAM(nn.Module):
    def __init__(self, in_planes, ratio=16, kernel_size=7):
        super(CBAM, self).__init__()
        self.ca = ChannelAttention(in_planes, ratio)  # 通道注意力实例
        self.sa = SpatialAttention(kernel_size)  # 空间注意力实例

    def forward(self, x):
        out = x * self.ca(x)  # 使用通道注意力加权输入特征图
        result = out * self.sa(out)  # 使用空间注意力进一步加权特征图
        return result  # 返回最终的特征图




class Dblock(nn.Module):
    def __init__(self, channel):
        super(Dblock, self).__init__()
        self.dilate1 = nn.Conv2d(channel, channel, kernel_size=3, dilation=1, padding=1)
        self.dilate2 = nn.Conv2d(channel, channel, kernel_size=3, dilation=2, padding=2)
        self.dilate3 = nn.Conv2d(channel, channel, kernel_size=3, dilation=4, padding=4)
        self.dilate4 = nn.Conv2d(channel, channel, kernel_size=3, dilation=8, padding=8)
        # self.dilate5 = nn.Conv2d(channel, channel, kernel_size=3, dilation=16, padding=16)
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x):
        dilate1_out = nonlinearity(self.dilate1(x))
        dilate2_out = nonlinearity(self.dilate2(dilate1_out))
        dilate3_out = nonlinearity(self.dilate3(dilate2_out))
        dilate4_out = nonlinearity(self.dilate4(dilate3_out))
        # dilate5_out = nonlinearity(self.dilate5(dilate4_out))
        out =x + dilate1_out + dilate2_out + dilate3_out + dilate4_out  # + dilate5_out
        #res = torch.cat([x, dilate1_out, dilate2_out, dilate3_out, dilate4_out], dim=1)
        return out




class ChannelShuffleSelector(nn.Module):
    def __init__(self, channels_per_branch, g , select_ratio):
        super().__init__()
        self.channels_per_branch = channels_per_branch
        self.select_ratio = select_ratio
        self.g = g

        # 通道评分网络
        self.scoring = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # 全局平均池化 [B,C,H,W] -> [B,C,1,1]
            nn.Flatten(),  # 展平为 [B,C]
            nn.Linear(channels_per_branch * 4, channels_per_branch * 4),  # 全连接层
            nn.LayerNorm(channels_per_branch * 4)  # 归一化
        )
        self.scoring2 = ChannelAttention(channels_per_branch * 4)

    def forward(self, feats):
        """
        输入:
            feats: List of 4 tensors, 每个形状 [B,64,H,W]
        输出:
            拼接后的特征 [B, 64*4*select_ratio, H,W]
        """
        # 步骤1: 通道拼接
        concat_feat = torch.cat(feats, dim=1)  # [B,256,H,W]

        # 步骤2: 通道维度打乱
        B, C, H, W = concat_feat.shape
        shuffle_idx = torch.randperm(C)  # 生成随机排列索引
        g2 = concat_feat[:, shuffle_idx, :, :]  # [B,256,H,W]

        # 步骤3: 通道评分
        #scores = self.scoring(g2)  # [B,256]
        scores2 = self.scoring2(g2)

        # 步骤4: 分组处理
        split_g2 = torch.split(g2, C//self.g, dim=1)  # 4个[B,64,H,W]
        split_scores = torch.split(scores2, C//self.g, dim=1)  # 4个[B,64]

        selected = []
        k = int(C//self.g * self.select_ratio)  # 每组的保留数

        # 遍历每个分组
        for group_feat, group_scores in zip(split_g2, split_scores):
            # 步骤5: 取每组Top-K通道
            # indices形状: [B, k]
            _, indices = torch.topk(group_scores, k, dim=1)

            # 扩展索引维度以匹配特征形状
            #expanded_indices = indices.unsqueeze(-1).unsqueeze(-1)  # [B,k,1,1]
            expanded_indices = indices.expand(-1, -1, H, W)  # [B,k,H,W]

            # 从分组特征中收集选中通道
            selected_feat = torch.gather(
                group_feat,
                dim=1,
                index=expanded_indices
            )  # [B,k,H,W]

            selected.append(selected_feat)

        # 步骤6: 最终拼接
        return torch.cat(selected, dim=1)  # [B,4*k,H,W]

class RAC(nn.Module):
    def __init__(self, in_ch, out_ch,g=8,select_ratio=0.3):
        super(RAC, self).__init__()
        # self.t1 = t1
        # self.t2 = t2
        # self.t3 = t3
        self.dsconvx = DSConv_pro(in_ch , in_ch, 9, 1, 0)
        self.dsconvy = DSConv_pro(in_ch , in_ch, 9, 1, 1)

        self.dilate1 = nn.Conv2d(in_ch, in_ch, kernel_size=3, dilation=1, padding=1)
        self.dilate2 = nn.Conv2d(in_ch, in_ch, kernel_size=3, dilation=3, padding=3)
        self.dilate3 = nn.Conv2d(in_ch, in_ch, kernel_size=3, dilation=7, padding=7)
        self.dilate4 = nn.Conv2d(in_ch, in_ch, kernel_size=3, dilation=9, padding=9)

        self.xz = ChannelShuffleSelector(in_ch, g=g, select_ratio=select_ratio)

        #print(in_ch*4*select_ratio)

        self.conv3 = nn.Conv2d(int(in_ch*4//g*select_ratio)*4*g//4, out_ch, 1)
        self.norm3 = nn.BatchNorm2d(out_ch)
        self.relu3 = nonlinearity


    def forward(self, x):
        b,c,h,w=x.size()

        dx1 = self.dsconvx(x)
        #dx1=self.dq(dx1)

        dy1 = self.dsconvy(x)
        #dy1=self.dq(dy1)

        dilate1_out = nonlinearity(self.dilate1(x))
        dilate2_out = nonlinearity(self.dilate2(x+dilate1_out))
        dilate3_out = nonlinearity(self.dilate3(x+dilate2_out))
        dilate4_out = nonlinearity(self.dilate4(x+dilate3_out))
        dilate_out=dilate1_out+dilate2_out+dilate3_out+dilate4_out

        dx = self.xz([dx1,dy1,dilate_out,x])


        x = self.conv3(dx)
        x = self.norm3(x)
        x = self.relu3(x)

        return x

class MDecoderBlock(nn.Module):
    def __init__(self, in_channels, n_filters,dilation):
        super(MDecoderBlock, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels // 4, 1)
        self.norm1 = nn.BatchNorm2d(in_channels // 4)
        self.relu1 = nonlinearity

        self.deconv2 = nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 3, stride=2, padding=1, output_padding=1)
        self.norm2 = nn.BatchNorm2d(in_channels // 4)
        self.relu2 = nonlinearity

        self.rac=RAC(in_channels // 4, n_filters)



    def forward(self, x):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)
        x = self.deconv2(x)
        x = self.norm2(x)
        x = self.relu2(x)
        x =self.rac(x)

        return x

class GEA(nn.Module):
    def __init__(self, channels, factor=8):
        super(GEA, self).__init__()
        self.groups = factor
        assert channels % self.groups == 0, "channels must be divisible by groups"
        self.group_channels = channels // self.groups
        self.softmax = nn.Softmax(dim=-1)
        self.gn = nn.GroupNorm(channels // self.groups, channels // self.groups)
        self.bn = nn.BatchNorm2d(channels // self.groups)
        self.conv1x1 = nn.Conv2d(channels // self.groups, channels // self.groups, kernel_size=1, stride=1, padding=0)
        self.conv3x3 = nn.Conv2d(channels // self.groups, channels // self.groups, kernel_size=3, stride=1, padding=1)
        self.agp = nn.AdaptiveAvgPool2d((1, 1))
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))
        self.conv1 = nn.Conv2d(1, 1, 7, padding=3, bias=False)


    def forward(self, x):
        b, c, h, w = x.size()
        group_x = x.reshape(b * self.groups, self.group_channels, h, w)  # (b*groups, c//groups, h, w)

        # 高度和宽度方向的池化
        pooled_h = self.pool_h(group_x)  # (b*groups, c//groups, 1, w)
        pooled_w = self.pool_w(group_x).permute(0, 1, 3, 2)  # (b*groups, c//groups, w, 1) -> (b*groups, c//groups, 1, w)

        # 合并池化结果并进行1x1卷积
        combined = torch.cat([pooled_h, pooled_w], dim=2)  # (b*groups, c//groups, h+1, w)
        conv1x1_out = self.conv1x1(combined)  # (b*groups, c//groups, h+1, w)
        x_h, x_w = torch.split(conv1x1_out, [h, w], dim=2)  # (b*groups, c//groups, h, w) 和 (b*groups, c//groups, w, w)

        # 逐元素相乘和GroupNorm
        x1 = self.gn(group_x * x_h.sigmoid() * x_w.permute(0, 1, 3, 2).sigmoid())  # (b*groups, c//groups, h, w)
        x2 = self.conv3x3(group_x)  # (b*groups, c//groups, h, w)

        # 自适应池化和softmax计算权重
        x11 = self.softmax(self.agp(x1))  # .reshape(b * self.groups, -1, 1).permute(0, 2, 1))
        x21 = self.softmax(self.agp(x2))  # .reshape(b * self.groups, -1, 1).permute(0, 2, 1))


        output = (group_x * x11.sigmoid() * x21.sigmoid()).reshape(b, c, h, w)
        return output


class RPE(nn.Module):
    def __init__(self, in_channels,n_filters, dilation):
        super(RPE, self).__init__()
        self.deconv1 = nn.Conv2d(
            in_channels, in_channels//4 , (1, dilation * 2 + 1), padding=(0, dilation)
        )
        self.deconv2 = nn.Conv2d(
            in_channels, in_channels//4 , (dilation * 2 + 1, 1), padding=(dilation, 0)
        )
        self.deconv3 = nn.Conv2d(
            in_channels, in_channels//4 , (dilation * 2 + 1, 1), padding=(dilation, 0)
        )
        self.deconv4 = nn.Conv2d(
            in_channels, in_channels//4 , (1, dilation * 2 + 1), padding=(0, dilation)
        )

        self.gea = GEA(in_channels)
        self.conv3 = nn.Conv2d(in_channels , n_filters, 1)
        self.norm3 = nn.BatchNorm2d(n_filters)
        self.relu3 = nonlinearity

    def forward(self, x):
        x1 = nonlinearity(self.deconv1(x))

        x2 = nonlinearity(self.deconv2(x))

        x3 = nonlinearity(self.inv_h_transform(self.deconv3(self.h_transform(x))))

        x4 = nonlinearity(self.inv_v_transform(self.deconv4(self.v_transform(x))))

        x = torch.cat((x1, x2, x3, x4), 1)

        x = self.gea(x)

        x = self.conv3(x)
        x = self.norm3(x)
        x = self.relu3(x)
        return x

    def h_transform(self, x):
        shape = x.size()
        x = torch.nn.functional.pad(x, (0, shape[-1]))
        x = x.reshape(shape[0], shape[1], -1)[..., :-shape[-1]]
        x = x.reshape(shape[0], shape[1], shape[2], 2 * shape[3] - 1)
        return x

    def inv_h_transform(self, x):
        shape = x.size()
        x = x.reshape(shape[0], shape[1], -1).contiguous()
        x = torch.nn.functional.pad(x, (0, shape[-2]))
        x = x.reshape(shape[0], shape[1], shape[-2], 2 * shape[-2])
        x = x[..., 0: shape[-2]]
        return x

    def v_transform(self, x):
        x = x.permute(0, 1, 3, 2)
        shape = x.size()
        x = torch.nn.functional.pad(x, (0, shape[-1]))
        x = x.reshape(shape[0], shape[1], -1)[..., :-shape[-1]]
        x = x.reshape(shape[0], shape[1], shape[2], 2 * shape[3] - 1)
        return x.permute(0, 1, 3, 2)

    def inv_v_transform(self, x):
        x = x.permute(0, 1, 3, 2)
        shape = x.size()
        x = x.reshape(shape[0], shape[1], -1)
        x = torch.nn.functional.pad(x, (0, shape[-2]))
        x = x.reshape(shape[0], shape[1], shape[-2], 2 * shape[-2])
        x = x[..., 0: shape[-2]]
        return x.permute(0, 1, 3, 2)


class ADecoderBlock(nn.Module):
    def __init__(self, in_channels, n_filters ,dilation):
        super(ADecoderBlock, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels // 4, 1)
        self.norm1 = nn.BatchNorm2d(in_channels // 4)
        self.relu1 = nonlinearity

        self.deconv2 = nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 3, stride=2, padding=1, output_padding=1)
        self.norm2 = nn.BatchNorm2d(in_channels // 4)
        self.relu2 = nonlinearity

        self.rpe = RPE(in_channels//4, n_filters, 4)


    def forward(self, x):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)
        x = self.deconv2(x)
        x = self.norm2(x)
        x = self.relu2(x)
        x = self.rpe(x)

        return x


class IFA(nn.Module):
    '''
    多特征融合 AFF
    '''

    def __init__(self, channels, r=4):
        super(IFA, self).__init__()
        #inter_channels = int(channels // r)

        self.conv = nn.Sequential(
            nn.Conv2d(channels * 2, channels , kernel_size=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )

        self.sa = SpatialAttention(7)  # 空间注意力实例
        self.ca = ChannelAttention(channels , 16)  # 通道注意力实例



    def forward(self, x, y):

        xs1 = self.sa(x) * x + x
        xs2 = self.sa(y) * y + y
        xo = xs1 + xs2

        xo = self.ca(xo) * xo

        return xo



class DD2(nn.Module):
    def __init__(self, num_classes=1, num_channels=3):
        super(DD2, self).__init__()

        dilation = [1, 2, 3, 4]
        d = [32,64,128,256]
        filters = [64, 128, 256, 512]
        resnet = models.resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.encoder3 = resnet.layer3
        self.encoder4 = resnet.layer4


        self.dblock = Dblock(512)


        # 使用新定义的辅助解码器 ADecoderBlock
        self.adecoder4 = ADecoderBlock(filters[3], filters[2], dilation=dilation[3])
        self.adecoder3 = ADecoderBlock(filters[2], filters[1], dilation=dilation[2])
        self.adecoder2 = ADecoderBlock(filters[1], filters[0], dilation=dilation[1])
        self.adecoder1 = ADecoderBlock(filters[0], filters[0], dilation=dilation[0])

        # 使用新定义的主解码器 MDecoderBlock
        self.mdecoder4 = MDecoderBlock(filters[3], filters[2], dilation=d[0])
        self.mdecoder3 = MDecoderBlock(filters[2], filters[1], dilation=d[1])
        self.mdecoder2 = MDecoderBlock(filters[1], filters[0], dilation=d[2])
        self.mdecoder1 = MDecoderBlock(filters[0], filters[0], dilation=d[3])


        self.ifa = IFA(filters[0])


        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x = self.firstmaxpool(x)
        e1 = self.encoder1(x)
        e2 = self.encoder2(e1)
        e3 = self.encoder3(e2)
        e4 = self.encoder4(e3)

        # Center
        e4 = self.dblock(e4)


        #Decoder
        #d4 = self.decoder4(e4) + e3
        d3 = self.adecoder3(e3) + e2
        d2 = self.adecoder2(d3) + e1
        d1 = self.adecoder1(d2)

        # MDecoder

        md4 = self.mdecoder4(e4) + e3

        md3 = self.mdecoder3(md4) + d3
        md2 = self.mdecoder2(md3) + d2
        md1 = self.mdecoder1(md2)

        out = self.ifa(md1, d1)

        out = self.finaldeconv1(out)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)


        return F.sigmoid(out)




if __name__ == '__main__':
    alexnet1 = DD2()  # 通道数等于输入图片的通道数
    print(alexnet1)
    test1 = torch.ones(1,3, 1024, 1024)  # 输入64batch  3通道 120*120的图片
    #flops, params = profile(alexnet1, (test1))
    #print('flops: %.2f G, params: %.2f M' % (flops / 1000000.0 / 1024.0, params / 1000000.0))
    test1 = alexnet1(test1)
    print(test1.shape)  # 输出无变化
    print(f"数值范围：[{test1.min():.3f},  {test1.max():.3f}]")  # 应在0-1之间

